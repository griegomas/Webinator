module.exports = {
  'secret':'mernsecure'
};
